import mysql from "mysql2"

export const mysqldb = mysql.createConnection({
  host:process.env.Mysqlhost,
  user:process.env.Mysqluser,
  password:process.env.Mysqlpassword,
  database:process.env.Mysqldatabase,
})