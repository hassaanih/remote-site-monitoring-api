export const firebaseConfig = {
    apiKey: process.env.FBapiKey,
    authDomain: process.env.FBauthDomain,
    databaseURL: process.env.FBdatabaseURL,
    projectId: process.env.FBprojectId,
    storageBucket: process.env.FBstorageBucket,
    messagingSenderId: process.env.FBmessagingSenderId,
    appId: process.env.FBappId,
};